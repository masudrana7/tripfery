<div class="rt-search-filter widget-babe-search-filter-rating">
	<?php
		$value = $_GET['rating_value'] ?? 0;
	?>
	<div class="rt-total-star">
		<div class="rt-input-radio">
			<input id="rt-rating-5" type="checkbox" class="rt-rating" name="rating_value" value="5" <?php checked($value, 5); ?> />

			<label for="rt-rating-5">
				<span class="rating-stars">
					<span class="star star-1" data-rating-val="1"><i class="fas fa-star"></i></span><span class="star star-2" data-rating-val="2"><i class="fas fa-star"></i></span>
					<span class="star star-3" data-rating-val="3"><i class="fas fa-star"></i></span><span class="star star-4" data-rating-val="4"><i class="fas fa-star"></i></span>
					<span class="star star-5" data-rating-val="5"><i class="fas fa-star"></i></span>
				</span>
			</label>
		</div>
	</div>
	<div class="rt-total-star">
		<div class="rt-input-radio">
			<input id="rt-rating-4" type="checkbox" class="rt-rating" name="rating_value" value="4" <?php checked($value, 4); ?> />
			<label for="rt-rating-4">
				<span class="rating-stars">
					<span class="star star-1" data-rating-val="1"><i class="fas fa-star"></i></span><span class="star star-2" data-rating-val="2"><i class="fas fa-star"></i></span>
					<span class="star star-3" data-rating-val="3"><i class="fas fa-star"></i></span><span class="star star-4" data-rating-val="4"><i class="fas fa-star"></i></span>
					<span class="star star-5" data-rating-val="5"><i class="far fa-star"></i></span>
				</span>
			</label>
		</div>
	</div>
	<div class="rt-total-star">
		<div class="rt-input-radio">
			<input id="rt-rating-3" type="checkbox" class="rt-rating" name="rating_value" value="3" <?php checked($value, 3); ?> />
			<label for="rt-rating-3">
				<span class="rating-stars">
					<span class="star star-1" data-rating-val="1"><i class="fas fa-star"></i></span><span class="star star-2" data-rating-val="2"><i class="fas fa-star"></i></span>
					<span class="star star-3" data-rating-val="3"><i class="fas fa-star"></i></span><span class="star star-4" data-rating-val="4"><i class="far fa-star"></i></span>
					<span class="star star-5" data-rating-val="5"><i class="far fa-star"></i></span>
				</span>
			</label>
		</div>
	</div>
	<div class="rt-total-star">
		<div class="rt-input-radio">
			<input id="rt-rating-2" type="checkbox" class="rt-rating" name="rating_value" value="2" <?php checked($value, 2); ?> />
			<label for="rt-rating-2">
				<span class="rating-stars">
					<span class="star star-1" data-rating-val="1"><i class="fas fa-star"></i></span><span class="star star-2" data-rating-val="2"><i class="fas fa-star"></i></span>
					<span class="star star-3" data-rating-val="3"><i class="far fa-star"></i></span><span class="star star-4" data-rating-val="4"><i class="far fa-star"></i></span>
					<span class="star star-5" data-rating-val="5"><i class="far fa-star"></i></span>
				</span>
			</label>
		</div>
	</div>
	<div class="rt-total-star">
		<div class="rt-input-radio">
			<input id="rt-rating-1" type="checkbox" class="rt-rating" name="rating_value" value="1" <?php checked($value, 1); ?> />
			<label for="rt-rating-1">
				<span class="rating-stars">
					<span class="star star-1" data-rating-val="1"><i class="fas fa-star"></i></span><span class="star star-2" data-rating-val="2"><i class="far fa-star"></i></span>
					<span class="star star-3" data-rating-val="3"><i class="far fa-star"></i></span><span class="star star-4" data-rating-val="4"><i class="far fa-star"></i></span>
					<span class="star star-5" data-rating-val="5"><i class="far fa-star"></i></span>
				</span>
			</label>
		</div>
	</div>
</div>